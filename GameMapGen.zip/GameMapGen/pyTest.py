from pygame.locals import *
import pygame, sys
from clyngor import ASP, solve

#answers = []

#answers = solve('puzzle_gen.lp')  # also accepts an iterable of file
#print(answers)

#does not do anything yet
MAPWIDTH2 = input ("Map Width: ")
MAPHEIGHT2 = input ("Map Height: ")

#map height and width have to be the same for the program to work
#so there will be an if statement to see which one is larger after the
#map has been generated. then black tiles will be added accordingly.

#for future sprite use
left = False
right = False
down = False
up = False
walkCount = 0

#array that holds the values from the generated file
fileList = []

#set up the tile colors
green = (40,255,30)
orange = (245, 165, 17)
red =  (155,20,30)
yellow = (255, 251, 8) 
purple = (118, 54, 153)
pink = (242, 179, 216)
blue = (7, 74, 181)
black = (0, 0, 0)

#read file and put into array
def readFile(fileName):
        fileObj = open(fileName, "r") #opens the file in read mode
        words = fileObj.read().splitlines() #puts the file into an array
        fileObj.close()
        return words

#divide array depending on map width
def divide_chunks(l, n):
    for i in range(0, len(l), n): 
        yield l[i:i + n]


#clingo
#dim(1) dim(2) dim(3) dim(4) 
#tile_type(red) tile_type(pink) 
#tile_type(yellow) tile_type(blue) 
#at(1,1,pink) at(2,1,red) at(3,1,red) 
#at(4,1,red) at(1,2,red) at(2,2,red) 
#at(3,2,red) at(4,2,red) at(1,3,red) 
#at(2,3,red) at(3,3,red) at(4,3,red) 
#at(1,4,red) at(2,4,red) at(3,4,red) 
#at(4,4,red)
#SATISFIABLE

#read through text file
#put into array
#try to delete unneeded info
#loop through array
#if array[i] = at(whatever) then add associated color
#to empty tileMap list depending on tilemap size


colours = {
    green: green,
    orange: orange,
    red: red,
    purple: purple,
    pink: pink,
    yellow: yellow,
    blue: blue,
    black:black
    }

#colours = {
   # green: 0,
 #   orange: 1,
  #  red: 2,
  #  purple: 3,
   # pink: 4,
  #  yellow: 5,
  #  blue: 6,
  #  black: 7
   # }

#take in tilemap file
#add black tiles to make map even

tilemap = []

fileList = readFile("answerSet.txt")

#for word in fileList:
    #print(word)

tiles = []

tilemap2 = [
        [purple, yellow, pink, pink, orange],
        [red, pink, green, orange, red],
        [orange, yellow, red ,blue, pink],
        [purple, blue, green, red, orange],
        [blue, red, pink, green, green],
        [pink, orange, orange, purple, red]

        ]

#print(tilemap2)

TILESIZE = 64
MAPWIDTH =  4
MAPHEIGHT = 4

for h in range(1,5):
    for w in range(1,5):

        sub = str(w) + "," + str(h)
        print (sub)
        for t in fileList:
            if (sub +',red') in t:
                tiles.append(red)
            if (sub +',purple') in t:
                tiles.append(purple)
            if (sub +',green') in t:
                tiles.append(green)
            if (sub +',pink') in t:
                tiles.append(pink)
            if (sub +',orange') in t:
                tiles.append(orange)
            if (sub +',yellow') in t:
                tiles.append(yellow)
            if (sub +',blue') in t:
                tiles.append(blue)

print(tiles)


# How many elements each
# list should have
n = 4
  
tilemap = list(divide_chunks(tiles, n))
print (tilemap)
  
# How many elements each
# list should have


#tilemap.append([black, black, black, black, black, black])

#for i in range(MAPHEIGHT):
    #tilemap[i].append(black)


pygame.init()
DISPLAYSURF = pygame.display.set_mode((MAPWIDTH*TILESIZE,MAPHEIGHT*TILESIZE))

while True:

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

        DISPLAYSURF.fill((0,0,0))

        for row in range(MAPWIDTH):
            print            
            for column in range(MAPHEIGHT):
                color = colours[tilemap[row][column]];                                                                                                         

                pygame.draw.rect(DISPLAYSURF, color, (column*TILESIZE, row*TILESIZE, TILESIZE, TILESIZE))


    pygame.display.update()